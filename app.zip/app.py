import os
from fastapi import FastAPI

app = FastAPI()

# Lazy load — don't import LangGraph at top level
graph = None

def get_graph():
    global graph
    if graph is None:
        # Import heavy deps only when first needed
        from your_langgraph_module import build_graph
        graph = build_graph()
    return graph

@app.get("/")
def home():
    return {"message": "Azure deployment works 🚀"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/run")
def run_agent(input: dict):
    g = get_graph()
    result = g.invoke(input)
    return result

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app:app", host="0.0.0.0", port=port)

